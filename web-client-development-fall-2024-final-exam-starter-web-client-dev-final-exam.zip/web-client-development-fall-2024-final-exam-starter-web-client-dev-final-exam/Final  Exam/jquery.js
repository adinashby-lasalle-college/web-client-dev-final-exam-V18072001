$(document).ready(function () {
    // Fade-in effect for main content on page load
    $("main").hide().fadeIn(1000); // 1-second fade-in

    // Slide-down effect for navigation menu on hover
    $("nav ul").hover(
        function () {
            $(this).stop().slideDown(300); // Slide down when hovered
        },
        function () {
            $(this).stop().slideUp(300); // Slide up when not hovered
        }
    );

    // Form Validation with Feedback
    $("#contactForm").on("submit", function (event) {
        let isValid = true;

        // Check each required field
        $("#contactForm input, #contactForm textarea").each(function () {
            if ($(this).val().trim() === "") {
                isValid = false;
                $(this).css("border", "2px solid red"); // Red border for empty fields
            } else {
                $(this).css("border", "1px solid #ccc"); // Default border for filled fields
            }
        });

        if (!isValid) {
            alert("Please fill out all fields.");
            event.preventDefault(); // Prevent form submission if validation fails
        } else {
            alert("Form submitted successfully!");
        }
    });

    // Toggle visibility for Resources list
    $("#toggleResourcesButton").on("click", function () {
        $("#resourcesList").slideToggle(500); // Toggle visibility with slide effect
    });
});
