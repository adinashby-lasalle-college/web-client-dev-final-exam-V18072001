// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", () => {
    // Form Validation
    const form = document.getElementById("contactForm");
    form.addEventListener("submit", (event) => {
        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const message = document.getElementById("message").value.trim();

        if (!name || !email || !message) {
            alert("All fields are required!");
            event.preventDefault();
        } else {
            alert("Form submitted successfully!");
        }
    });

    // Toggle Resources
    const toggleResourcesButton = document.getElementById("toggleResourcesButton");
    const resourcesList = document.getElementById("resourcesList");
    toggleResourcesButton.addEventListener("click", () => {
        resourcesList.style.display = resourcesList.style.display === "none" ? "block" : "none";
    });

    // Scroll to Top Functionality
    const scrollToTopButton = document.getElementById("scrollToTop");
    window.addEventListener("scroll", () => {
        if (window.scrollY > 300) {
            scrollToTopButton.style.display = "block";
        } else {
            scrollToTopButton.style.display = "none";
        }
    });

    scrollToTopButton.addEventListener("click", () => {
        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    });

    // Dynamic Content Update - Add New Project Row
    const addProjectButton = document.getElementById("addProjectButton");
    addProjectButton.addEventListener("click", () => {
        const table = document.querySelector("table tbody");
        const newRow = document.createElement("tr");

        newRow.innerHTML = `
            <td>New Project</td>
            <td>This is a dynamically added project.</td>
            <td>${new Date().toLocaleDateString()}</td>
        `;
        table.appendChild(newRow);
    });
});
